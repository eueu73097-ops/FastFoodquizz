# Fast food quiz

A Pen created on CodePen.

Original URL: [https://codepen.io/Jorge-Cunha-the-decoder/pen/emJJjmm](https://codepen.io/Jorge-Cunha-the-decoder/pen/emJJjmm).

