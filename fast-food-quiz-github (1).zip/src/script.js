const perguntasOriginais = [
  {
    pergunta: "Qual é o principal risco à saúde associado ao consumo excessivo de fast food?",
    respostas: {
      A: "Aumento de energia",
      B: "Obesidade e doenças cardíacas",
      C: "Aumento de músculos",
      D: "Melhora na visão",
    },
    respostaCorreta: "B",
    explicacao: "O consumo excessivo de fast food pode levar à obesidade, diabetes tipo 2 e doenças cardíacas.",
  },
  {
    pergunta: "O fast food pode afetar qual parte do corpo?",
    respostas: {
      A: "O cérebro e o sistema nervoso",
      B: "O fígado e o pâncreas",
      C: "Os ossos e músculos",
      D: "O sistema respiratório",
    },
    respostaCorreta: "B",
    explicacao: "O consumo de fast food em excesso pode prejudicar órgãos como o fígado e o pâncreas, levando a doenças como a diabetes.",
  },
  {
    pergunta: "Qual destes alimentos é considerado fast food?",
    respostas: {
      A: "Pizza",
      B: "Salada",
      C: "Arroz com feijão",
      D: "Sopa caseira",
    },
    respostaCorreta: "A",
    explicacao: "Pizza é um dos alimentos mais populares no fast food.",
  },
  {
    pergunta: "Qual é a principal característica do fast food?",
    respostas: {
      A: "Baixo custo e preparo rápido",
      B: "Alta qualidade nutricional",
      C: "Alimentos orgânicos",
      D: "Receitas caseiras",
    },
    respostaCorreta: "A",
    explicacao: "Fast food é conhecido pelo preço acessível e preparo rápido.",
  },
  {
    pergunta: "Qual refrigerante é mais associado ao fast food?",
    respostas: {
      A: "Guaraná",
      B: "Coca-Cola",
      C: "Suco natural",
      D: "Água",
    },
    respostaCorreta: "B",
    explicacao: "A Coca-Cola é a bebida mais popular em cadeias de fast food.",
  },
  {
    pergunta: "Qual desses ingredientes é comum em fast food, mas pouco saudável?",
    respostas: {
      A: "Óleo vegetal trans",
      B: "Mel",
      C: "Azeite de oliva",
      D: "Vinagre",
    },
    respostaCorreta: "A",
    explicacao: "Óleos vegetais trans são comuns em fast food e prejudicam a saúde cardiovascular.",
  },
  {
    pergunta: "Qual é uma alternativa mais saudável ao fast food?",
    respostas: {
      A: "Comida congelada",
      B: "Alimentos frescos e caseiros",
      C: "Bebidas energéticas",
      D: "Doces industrializados",
    },
    respostaCorreta: "B",
    explicacao: "Alimentos frescos e preparados em casa são mais saudáveis que fast food.",
  },
  {
    pergunta: "Por que o fast food pode causar problemas digestivos?",
    respostas: {
      A: "Pela alta quantidade de fibras",
      B: "Pela falta de nutrientes e excesso de gorduras",
      C: "Por ser muito ácido",
      D: "Por conter vitaminas em excesso",
    },
    respostaCorreta: "B",
    explicacao: "O excesso de gorduras e a baixa qualidade nutricional causam problemas digestivos.",
  },
  {
    pergunta: "Qual desses hábitos ajuda a reduzir os efeitos negativos do fast food?",
    respostas: {
      A: "Beber muita água",
      B: "Exercícios físicos regulares",
      C: "Comer fast food todos os dias",
      D: "Evitar alimentos frescos",
    },
    respostaCorreta: "B",
    explicacao: "Exercícios físicos ajudam a compensar os efeitos negativos do fast food.",
  },
];

let perguntas = [];
let pontos = 0;
let perguntaAtual = 0;
let tempoInicial;
let tempoFinal;
let errouAlguma = false;
const tabelaPontuacao = [];

const feedback = document.getElementById("feedback");
const questionElem = document.getElementById("question");
const opcoesBtns = document.querySelectorAll(".opcao");
const pontosElem = document.getElementById("pontos");
const perguntaContainer = document.getElementById("perguntaContainer");
const reiniciarDiv = document.getElementById("reiniciar");
const btnReiniciar = document.getElementById("btnReiniciar");
const tabela = document.getElementById("tabelaPontuacao");
const tbody = tabela.querySelector("tbody");
const tabelaTitulo = document.getElementById("tabelaTitulo");

function embaralharArray(array) {
  for (let i = array.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [array[i], array[j]] = [array[j], array[i]];
  }
  return array;
}

function iniciarJogo() {
  pontos = 0;
  perguntaAtual = 0;
  errouAlguma = false;
  pontosElem.textContent = pontos;
  reiniciarDiv.style.display = "none";
  perguntaContainer.style.display = "block";
  tabela.style.display = "none";
  tabelaTitulo.style.display = "none";

  perguntas = [...perguntasOriginais];
  perguntas = embaralharArray(perguntas);

  tempoInicial = Date.now();
  mostrarPergunta();
}

function mostrarPergunta() {
  const p = perguntas[perguntaAtual];
  questionElem.textContent = p.pergunta;

  opcoesBtns.forEach((btn) => {
    const letra = btn.getAttribute("data-letra");
    btn.textContent = p.respostas[letra];
    btn.disabled = false;
    btn.classList.remove("correto", "errado");
  });

  feedback.style.opacity = 0;
}

function verificarResposta(event) {
  const resposta = event.target.getAttribute("data-letra");
  const p = perguntas[perguntaAtual];

  opcoesBtns.forEach((btn) => (btn.disabled = true));

  if (resposta === p.respostaCorreta) {
    pontos++;
    feedback.textContent = "Correto!";
    feedback.className = "correto";
  } else {
    feedback.textContent = "Errado! " + p.explicacao;
    feedback.className = "errado";
    errouAlguma = true;
  }

  opcoesBtns.forEach((btn) => {
    const letra = btn.getAttribute("data-letra");
    if (letra === p.respostaCorreta) {
      btn.classList.add("correto");
    } else if (letra === resposta) {
      btn.classList.add("errado");
    }
  });

  pontosElem.textContent = pontos;
  feedback.style.opacity = 1;

  setTimeout(() => {
    feedback.style.opacity = 0;
    perguntaAtual++;
    if (perguntaAtual < perguntas.length) {
      mostrarPergunta();
    } else {
      tempoFinal = Date.now();
      finalizarJogo();
    }
  }, 2500);
}

function finalizarJogo() {
  const tempoTotal = (tempoFinal - tempoInicial) / 1000;
  perguntaContainer.style.display = "none";
  reiniciarDiv.style.display = "block";

  alert(`Jogo finalizado! Sua pontuação foi: ${pontos} em ${tempoTotal.toFixed(2)} segundos.`);

  if (!errouAlguma) {
    const nomeJogador = prompt("Parabéns! Digite seu nome para o ranking:", "Jogador");
    if (nomeJogador) {
      tabelaPontuacao.push({ nome: nomeJogador, pontos, tempo: tempoTotal });
    }
  } else {
    alert("Você errou uma ou mais perguntas. Para aparecer no ranking, é necessário acertar todas!");
  }

  mostrarRanking();
}

function mostrarRanking() {
  if (tabelaPontuacao.length === 0) {
    tabela.style.display = "none";
    tabelaTitulo.style.display = "none";
    return; // Não mostra ranking vazio
  }

  tabelaPontuacao.sort((a, b) => b.pontos - a.pontos || a.tempo - b.tempo);
  tbody.innerHTML = "";
  tabela.style.display = "table";
  tabelaTitulo.style.display = "table-row";

  tabelaPontuacao.forEach((item, i) => {
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td>${i + 1}</td>
      <td>${item.nome}</td>
      <td>${item.tempo.toFixed(2)} s</td>
    `;
    tbody.appendChild(tr);
  });
}

function reiniciarJogo() {
  iniciarJogo();
}

opcoesBtns.forEach((btn) => btn.addEventListener("click", verificarResposta));
btnReiniciar.addEventListener("click", reiniciarJogo);

window.onload = iniciarJogo;
